<?php

require './vendor/autoload.php';

require './functions/functions.php';


send_email('edwin@gmail.com', 'testing UPDATED', 'SOME MESSAGE');

