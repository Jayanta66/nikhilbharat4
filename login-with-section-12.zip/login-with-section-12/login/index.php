<?php include("includes/header.php") ?>

  
  <?php include("includes/nav.php") ?>




	<div class="jumbotron">

		<?php display_message(); ?>
		<h1 class="text-center"> Home </h1>
	</div>


<?php include("includes/footer.php") ?>